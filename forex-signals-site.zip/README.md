# Forex Signals Site

A simple React-based Forex Signals platform hosted on GitHub Pages.

## 🚀 Deploy
1. Run `npm install`
2. Run `npm run deploy`
3. Your site will be live at:
   https://YOUR-USERNAME.github.io/forex-signals-site
